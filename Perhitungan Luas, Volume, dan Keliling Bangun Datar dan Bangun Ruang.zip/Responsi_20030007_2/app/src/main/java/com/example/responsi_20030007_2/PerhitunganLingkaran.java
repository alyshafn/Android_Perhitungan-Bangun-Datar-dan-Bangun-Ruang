package com.example.responsi_20030007_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class PerhitunganLingkaran extends AppCompatActivity {
    Button hitungluas, hitungkeliling, reset, kembali;
    EditText isijarijari;
    TextView tvluas, tvkeliling;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perhitungan_lingkaran);

        hitungluas = findViewById(R.id.hitungluas);
        hitungkeliling = findViewById(R.id.hitungkeliling);
        reset = findViewById(R.id.reset);
        kembali = findViewById(R.id.kembali);
        isijarijari = findViewById(R.id.jarijari);
        tvluas = findViewById(R.id.luas);
        tvkeliling = findViewById(R.id.keliling);

        hitungluas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double jarijari = Double.valueOf(isijarijari.getText().toString());
                Double phi = 3.14;

                Double luaslingkaran = (phi * jarijari * jarijari);
                tvluas.setText("" +luaslingkaran);
            }
        });

        hitungkeliling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double jarijari = Double.valueOf(isijarijari.getText().toString());
                Double phi = 3.14;

                Double kelilinglingkaran = (2 * phi * jarijari);

                tvkeliling.setText(""+kelilinglingkaran);
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isijarijari.setText("");
                tvkeliling.setText("");
                tvluas.setText("");
            }
        });

        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent kembali = new Intent(PerhitunganLingkaran.this, MainActivity.class);
                startActivity(kembali);
            }
        });
    }
}