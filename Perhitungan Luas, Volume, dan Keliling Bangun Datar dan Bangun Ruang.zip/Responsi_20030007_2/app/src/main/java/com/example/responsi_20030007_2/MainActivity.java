package com.example.responsi_20030007_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btnnext;
    Spinner sp_pilihmateri;
    String pilihmateri[] = {"Pilih Materi", "Bangun Datar - Lingkaran", "Bangun Ruang - Bola"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sp_pilihmateri = (Spinner) findViewById(R.id.pilihmateri);
        btnnext = findViewById(R.id.next);
        TextView materi = findViewById(R.id.setmateri);

        ArrayAdapter pilihan = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, pilihmateri);
        pilihan.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_pilihmateri.setAdapter(pilihan);
        sp_pilihmateri.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                materi.setText(pilihmateri[i]);
                String pilih = materi.getText().toString();
                if (pilih == "Bangun Datar - Lingkaran") {
                    btnnext.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent next = new Intent(MainActivity.this,PerhitunganLingkaran.class);
                            startActivity(next);
                        }
                    });
                } else if (pilih == "Bangun Ruang - Bola") {
                    btnnext.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent next = new Intent(MainActivity.this,PerhitunganBola.class);
                            startActivity(next);
                        }
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                materi.setText("Gagal");
            }
        });
    }
}