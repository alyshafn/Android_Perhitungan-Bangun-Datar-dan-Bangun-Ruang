package com.example.responsi_20030007_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PerhitunganBola extends AppCompatActivity {
    Button htgvolume, htgkeliling, rst, back;
    EditText edjarijari;
    TextView tvvolume, tvkel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perhitungan_bola);

        htgvolume = findViewById(R.id.hitungvolume);
        htgkeliling = findViewById(R.id.hitungkel);
        rst = findViewById(R.id.rst);
        back = findViewById(R.id.back);
        edjarijari = findViewById(R.id.jari2);
        tvvolume = findViewById(R.id.volume);
        tvkel = findViewById(R.id.kel);

        htgvolume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double r = Double.valueOf(edjarijari.getText().toString());
                Double phi = 3.14;

                Double volumebola = (4*phi*r*r*r)/3;

                tvvolume.setText(""+volumebola);
            }
        });

        htgkeliling.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double r = Double.valueOf(edjarijari.getText().toString());
                Double phi = 3.14;

                Double kelilingbola = (4*phi*r*r)/3;

                tvkel.setText(""+kelilingbola);
            }
        });

        rst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edjarijari.setText("");
                tvvolume.setText("");
                tvkel.setText("");
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(PerhitunganBola.this, MainActivity.class);
                startActivity(back);
            }
        });
    }
}